﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Create Connection Object
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = |DataDirectory|Database1.mdf; Integrated Security = True";
            
            // Create SQL Insert Statement
            string strInsert = "INSERT INTO MEMBER "
                + " VALUES('" + idt.Text + "', '"
                + fnamet.Text + "', '"
                + lnamet.Text + "', '"
                + RadioButtonList1.SelectedValue + "', '"
                + addresst.Text + "', '"
                + emailt.Text + "', '"
                + nationality.SelectedValue + "', '"
                + phonet.Text + "', '"
                + major.SelectedValue + "')";

            // Create SQL Command
            SqlCommand cmdInsert = new SqlCommand(strInsert, conn);
            try
            {
                conn.Open();

                cmdInsert.ExecuteNonQuery();

                conn.Close();
                Label1.Text = "Welcome" + fnamet.Text + "Your account is made";
            }

            catch (SqlException err)
            {
                if (err.Number == 26727)
                    Label1.Text = "Username alread exits";
                else
                    Label1.Text = "Sorry, Database Error";
            }
            catch
            {
                Label1.Text = "sorry, database error";
            }
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}